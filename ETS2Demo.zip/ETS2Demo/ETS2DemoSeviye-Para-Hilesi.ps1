# --- OTO YÖNETİCİ VE EXECUTION POLICY BYPASS (Kendi Kendini Yetkilendirme) ---
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $powershell = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
    Start-Process $powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

# --- WINDOWS FORMS VE DRAWING KÜTÜPHANELERİ ---
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# --- C# BELLEK OKUMA/YAZMA KÜTÜPHANESİ ---
$cSharpCode = @"
using System;
using System.Runtime.InteropServices;
using System.Diagnostics;

public class Memory {
    [DllImport("kernel32.dll")] public static extern IntPtr OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);
    [DllImport("kernel32.dll")] public static extern bool ReadProcessMemory(IntPtr hProcess, long lpBaseAddress, byte[] lpBuffer, int dwSize, ref int lpNumberOfBytesRead);
    [DllImport("kernel32.dll")] public static extern bool WriteProcessMemory(IntPtr hProcess, long lpBaseAddress, byte[] lpBuffer, int dwSize, ref int lpNumberOfBytesWritten);

    public static bool Apply(int type, int val) {
        Process[] p = Process.GetProcessesByName("eurotrucks2");
        if (p.Length == 0) return false;
        
        long baseAddr = p[0].MainModule.BaseAddress.ToInt64();
        IntPtr h = OpenProcess(0x0038, false, p[0].Id);
        if (h == IntPtr.Zero) return false;

        byte[] buf = new byte[8];
        int r = 0;

        // Kök Pointer: eurotrucks2.exe + 01C59D88
        ReadProcessMemory(h, baseAddr + 0x01C59D88, buf, 8, ref r);
        long root = BitConverter.ToInt64(buf, 0);
        if (root == 0) return false;

        long target = 0;
        if (type == 1) {
            // Para: [root + 0x10] -> +0x10
            ReadProcessMemory(h, root + 0x10, buf, 8, ref r);
            long step2 = BitConverter.ToInt64(buf, 0);
            target = step2 + 0x10;
        } else {
            // XP: root + 0x1964
            target = root + 0x1964;
        }

        byte[] wBuf = BitConverter.GetBytes(val);
        return WriteProcessMemory(h, target, wBuf, 4, ref r);
    }
}
"@

Add-Type -TypeDefinition $cSharpCode -ReferencedAssemblies 'System.Windows.Forms', 'System.Drawing'

# --- ARAYÜZ (GUI) TASARIMI ---
$form = New-Object System.Windows.Forms.Form
$form.Text = 'ETS2 Demo Trainer'
$form.Size = New-Object System.Drawing.Size(320, 230)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false

# Para Etiketi ve Kutusu
$lblP = New-Object System.Windows.Forms.Label
$lblP.Text = 'Para Miktari (Max 999999999):'
$lblP.Location = New-Object System.Drawing.Point(20, 20)
$lblP.AutoSize = $true

$txtP = New-Object System.Windows.Forms.TextBox
$txtP.Location = New-Object System.Drawing.Point(20, 40)
$txtP.Size = New-Object System.Drawing.Size(150, 20)
$txtP.Text = '999999999'

$btnP = New-Object System.Windows.Forms.Button
$btnP.Text = 'Parayi Degistir'
$btnP.Location = New-Object System.Drawing.Point(180, 38)
$btnP.Size = New-Object System.Drawing.Size(110, 23)

# XP Etiketi ve Kutusu
$lblX = New-Object System.Windows.Forms.Label
$lblX.Text = 'XP Miktari (Max 999999999):'
$lblX.Location = New-Object System.Drawing.Point(20, 80)
$lblX.AutoSize = $true

$txtX = New-Object System.Windows.Forms.TextBox
$txtX.Location = New-Object System.Drawing.Point(20, 100)
$txtX.Size = New-Object System.Drawing.Size(150, 20)
$txtX.Text = '999999999'

$btnX = New-Object System.Windows.Forms.Button
$btnX.Text = 'XP Degistir'
$btnX.Location = New-Object System.Drawing.Point(180, 98)
$btnX.Size = New-Object System.Drawing.Size(110, 23)

# Buton Tıklama İşlemleri
$btnP.Add_Click({
    [int]$val = 0
    if ([int]::TryParse($txtP.Text, [ref]$val)) {
        if ($val -gt 999999999) { $val = 999999999 }
        if ([Memory]::Apply(1, $val)) {
            [System.Windows.Forms.MessageBox]::Show('Para Basariyla Guncellendi!','Basarili')
        } else {
            [System.Windows.Forms.MessageBox]::Show('Oyun Bulunamadi veya Bellek Okunamadi!','Hata')
        }
    }
})

$btnX.Add_Click({
    [int]$val = 0
    if ([int]::TryParse($txtX.Text, [ref]$val)) {
        if ($val -gt 999999999) { $val = 999999999 }
        if ([Memory]::Apply(2, $val)) {
            [System.Windows.Forms.MessageBox]::Show('XP Basariyla Guncellendi!','Basarili')
        } else {
            [System.Windows.Forms.MessageBox]::Show('Oyun Bulunamadi veya Bellek Okunamadi!','Hata')
        }
    }
})

# Elemanları Ekle ve Çalıştır
$form.Controls.AddRange(@($lblP, $txtP, $btnP, $lblX, $txtX, $btnX))
[System.Windows.Forms.Application]::Run($form)